package Compilador05;

public class Archivo1 {
	public static void main(String[] args){
		LeerArchivo arch = new LeerArchivo();
		
		System.out.println(arch.leerTxt("D:\\Documentos\\JavaProgramas\\Compiladores\\prueba.txt"));
	}
}
