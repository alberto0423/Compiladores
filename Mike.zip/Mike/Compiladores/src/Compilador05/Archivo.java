package Compilador05;
import java.io.FileWriter;
import java.io.PrintWriter;
public class Archivo {

	public static void main(String[] args) {
		FileWriter fichero = null;
		PrintWriter pw = null;
		String[][] matriz =new String[4][4];
		matriz[0][0]="I/E";
		matriz[0][1]="letra";
		matriz[0][2]="Digito";
		matriz[0][3]="FC";
		matriz[1][0]="1";
		matriz[1][1]="3";
		matriz[1][2]="2";
		matriz[1][3]="error";
		matriz[2][0]="2";
		matriz[2][1]="error";
		matriz[2][2]="error";
		matriz[2][3]="error";
		matriz[3][0]="3";
		matriz[3][1]="3";
		matriz[3][2]="3";
		matriz[3][3]="aceptar";
		
		try {
			fichero = new FileWriter("prueba.txt");
			pw = new PrintWriter(fichero);
			for (int i = 0; i < 4; i++) {
				System.out.println();
				for (int j = 0; j < 4; j++) {
					pw.print(matriz[i][j]+" ");
				}
				pw.println(" ");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if (null != fichero){
					fichero.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}
