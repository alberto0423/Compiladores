/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Archivos;

import GUI.Inicio;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author J-ALS
 */
public class FileChooser extends Archivos{
   
    public static void escojerARchivo(){
        try {
         JFileChooser   chooser =   new JFileChooser();
         FileNameExtensionFilter extensionFilter =   new FileNameExtensionFilter( ".txt,.doc",".txt",".doc");
         chooser.setFileFilter(extensionFilter);
         chooser.showOpenDialog(chooser);
         chooser.getSelectedFile();
         
            
        } catch (Exception e) {
        }
    }
    
   
}
