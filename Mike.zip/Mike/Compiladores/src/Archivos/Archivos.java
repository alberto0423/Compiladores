/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Archivos;

import GUI.Inicio;
import java.io.*;
import javafx.beans.binding.Bindings;
import javax.swing.*;
import jdk.jfr.events.FileWriteEvent;
import static GUI.Inicio.*;
import java.util.ArrayList;

/**
 *
 * @author J-ALS
 */
public class Archivos {
//Metodo para crear un nuevo archivo
    public static void crearArchivo(String nombreArchivos) {
        File file = new File(nombreArchivos);
        String aux;
        int recibido = 0;
        recibido = JOptionPane.showConfirmDialog(null, "¿Desea crear un nuevo archivo?", "Crear Archivo", JOptionPane.OK_OPTION);

        if (JOptionPane.OK_OPTION == recibido && !file.exists()) {
            String nombre = JOptionPane.showInputDialog(null, "Ingrese el nombre de su archivo: ");
            nombre = nombreArchivos;
            try {

                PrintWriter printWriter = new PrintWriter(new FileWriter(nombre));
                JOptionPane.showMessageDialog(null, "Se ha creado el archivo de manera exitosa");
                printWriter.close();

            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Hubo un problema al crear el archivo");

            }

        } else if (file.exists()) {
            recibido = JOptionPane.showConfirmDialog(null, "Ya existe un archivo desea crear otro nuevo", "Crear nuevo", recibido);
            String nuevoNombre = JOptionPane.showInputDialog(null, "Ingrese el nombre de su archivo: ");
            aux = nuevoNombre;

            if (JOptionPane.OK_OPTION == recibido) {

                try {

                    PrintWriter printWriter = new PrintWriter(new FileWriter(aux));
                    JOptionPane.showMessageDialog(null, "Se ha creado el archivo de manera exitosa");
                    printWriter.close();

                } catch (Exception e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Hubo un problema al crear el archivo");

                }
            }
        }
    }
//Metodo para escribir en un nuevor archivo
    public static void escribirArchivo(String nombreArchivo) {
        File file = new File(nombreArchivo);
        try {

            PrintWriter printWriter = new PrintWriter(new FileWriter(file));
            String contenido = jTextFieldEntrada.getText();
            jTextArea.setText(contenido);
            printWriter.println(contenido);
            printWriter.println();
            printWriter.println("Fin de escritura");
            jTextFieldEntrada.setText("");
            printWriter.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//Metodo para leer el archivo con un Jfile chooser
    public static void leerArchivo(String nombreArchivo) {
        String texto = "";
        String lectura;
        File file = new File(nombreArchivo);
        JFileChooser jfc = new JFileChooser();
        try {
            jfc.showOpenDialog(jfc);
            file = jfc.getSelectedFile();
            if (file != null) {
                BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
                lectura = bufferedReader.readLine();
                while (lectura != null) {
                    texto += lectura + "\n";
                    jTextArea.setText(texto);
                    System.out.println("Lectura: " + texto);

                    lectura = bufferedReader.readLine();

                }
                if (jTextArea.getText().length() != 0) {
                    JOptionPane.showMessageDialog(null, "El archivo se cargó de manera exitosa...");

                }
                bufferedReader.close();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//Metodo para anexar informacion a una ya existente sin sobrescribir
    public static void anexarArchivo(String nombreArchivo) {
        String aux = "";
        File file = new File(nombreArchivo);
        try {
            PrintWriter printWriter = new PrintWriter(new FileWriter(file, true));
            String contenido = jTextFieldEntrada.getText();
            if (jTextArea.getText().length() == 0) {
                JOptionPane.showMessageDialog(null, "Debe de ingresar los datos en los campos");
            } else {

                printWriter.close();
                printWriter.println();
                printWriter.println("Fin de anexar");
            }
            printWriter.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
