package Compilador11;

public class SintacticoE {
    
    private String cadena = "( num + num ) ;";
    private String token;
    private int indice = 0;
    private boolean correcto = false;
    private boolean error =  false;

    public static void main(String[] args) {
        SintacticoE app = new SintacticoE();
        app.token = app.getToken();
        app.metodo_S();
        if (app.isError()){//(app.IsError())
            System.out.println("Error de sintaxis");
        }else {
            System.out.println("Correcto");
        }
    }
    
    private void metodo_S(){
        metodo_E();
        if (token!= null && token.equals(";")){
            correcto = true;
        }else{
            error = true;
        }
    }
    
    private void metodo_E(){
        if (token!= null && token.equals("(")){
            token = getToken();
            metodo_E();
            if (token!= null && token.equals(")")){
                token =getToken();
                if(token!= null && token.equals(";")){
                    metodo_X();
                }
            } else {
                token = getToken();
                error= true;
            }
        }else if (token!= null && token.equals("num")){
            token = getToken();
            if (token!= null && token.equals(";")){
                metodo_X();
            }
        }
    }
    
    private void metodo_X() {
        if (token!= null && token.equals("*")){
            token = getToken();
            metodo_E();
            if (token!= null){
                //token = getToken();
                metodo_X();
            }
        } else if (token!= null && token.equals("+")){
            token = getToken();
            metodo_E();
            if (token!= null){
                //token = getToken();
                metodo_X();
            }
        }
    }
    
    private String getToken() {
        String token = null;
        if(indice < cadena.split(" ").length){
            token = cadena.split(" ")[indice];
            indice++;
        }
        return token;
    }
    public boolean isError(){
        return error;
    }
}
