/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Compilador07;

public enum Tokens {
    ID,INT,OR,AND,TRUE,FALSE,NOT,PARENT_IZQ,PARENT_DER,ERROR,SI,SII
}
