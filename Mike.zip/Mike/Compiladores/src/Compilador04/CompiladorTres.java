package Compilador04;

import javax.swing.JOptionPane;

public class CompiladorTres {

    private String cadena = "";
    private boolean aceptar = false;
    private int error = 0;
    private int indice = 0;
    private int estado = 1;
    private char simbolo;

    public static void main(String[] args) {
        CompiladorTres obj = new CompiladorTres();
        obj.cadena = JOptionPane.showInputDialog("Dame la cadena");
        obj.simbolo = obj.siguienteCaracter();
        while (obj.simbolo != ' ' || obj.error != 0) {
            switch (obj.estado) {
                case 1:
                    if (obj.simbolo == 'a') {
                        obj.estado = 2;
                        obj.aceptar = true;
                    } else if (obj.simbolo == 'b') {
                        obj.estado = 3;
                    } else if (obj.simbolo == 'c'){
                        obj.estado = 4;
                    } else{
                    	obj.error = 0;
                    }
                    break;
                case 2:
                	if (obj.simbolo == 'a') {
                        obj.estado = 2;
                        obj.aceptar = true;
                    } else if (obj.simbolo == 'b') {
                        obj.estado = 3;
                    } else if (obj.simbolo == 'c'){
                        obj.estado = 5;
                        obj.aceptar = true;
                    } else{
                    	obj.error = 0;
                    }
                    break;
                case 3:
                	if (obj.simbolo == 'a') {
                        obj.estado = 2;
                        obj.aceptar = true;
                    } else if (obj.simbolo == 'b') {
                        obj.estado = 3;
                    } else if (obj.simbolo == 'c'){
                        obj.estado = 4;
                    } else{
                    	obj.error = 0;
                    }
                    break;
                case 4:
                	if (obj.simbolo == 'a') {
                        obj.estado = 2;
                        obj.aceptar = true;
                    } else if (obj.simbolo == 'b') {
                        obj.estado = 3;
                    } else if (obj.simbolo == 'c'){
                        obj.estado = 4;
                    } else{
                    	obj.error = 0;
                    }
                    break;
                case 5:
                	if (obj.simbolo == 'a') {
                        obj.estado = 2;
                        obj.aceptar = true;
                    } else if (obj.simbolo == 'b') {
                        obj.estado = 3;
                    } else if (obj.simbolo == 'c'){
                        obj.estado = 5;
                        obj.aceptar = true;
                    } else{
                    	obj.error = 0;
                    }
                    break;
            }
            obj.simbolo = obj.siguienteCaracter();

        }
        if (!obj.aceptar) {
            JOptionPane.showMessageDialog(null, "cadena invalida");
        } else {
            JOptionPane.showMessageDialog(null, "cadena valida");

        }
    }

    private char siguienteCaracter() {
        char c = ' ';
        if (indice < cadena.length()) {
            c = cadena.charAt(indice);
            indice++;
        }
        return c;
    }

}
