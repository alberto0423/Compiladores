package Compilador02;
import javax.swing.JOptionPane;

public class Compilador_abcac{

	private String cadena="";
	private int aceptar=1;
	private int error=0;
	private int indice=0;

	public static void main(String[] args){
		Compilador_abcac obj=new Compilador_abcac();
		obj.cadena=JOptionPane.showInputDialog("Dame la cadena");
		if(obj.aceptar==obj.estado_A()){
			JOptionPane.showInputDialog(null, "Cadena Valida");
		}else{
			JOptionPane.showInputDialog(null, "Cadena Invalida");
		}
	}

	private char siguienteCaracter(){
		char c=' ';
		if(indice<cadena.length()){
			c=cadena.charAt(indice);
			indice++;
		}
		return c;
	}

	private int estado_A(){
		char c=siguienteCaracter();
		switch(c){
			case 'a': return estado_B();
			case 'b': return estado_C();
			case 'c': return estado_D();
				default: return error;
		}
	}
	
	private int estado_B(){
			char c=siguienteCaracter();
		switch(c){
			case 'a': return estado_B();
			case 'b': return estado_C();
			case 'c': return estado_E();
			case ' ': return aceptar;
				default: return error;
		}
	}
	
	private int estado_C(){
			char c=siguienteCaracter();
		switch(c){
			case 'a': return estado_B();
			case 'b': return estado_C();
			case 'c': return estado_D();
				default: return error;
		}
	}

	private int estado_D(){
			char c=siguienteCaracter();
		switch(c){
			case 'a': return estado_B();
			case 'b': return estado_C();
			case 'c': return estado_D();
				default: return error;
		}
	}

	private int estado_E(){
			char c=siguienteCaracter();
		switch(c){
			case 'a': return estado_B();
			case 'b': return estado_C();
			case 'c': return estado_E();
			case ' ': return aceptar;
				default: return error;	
		}
	}
}
